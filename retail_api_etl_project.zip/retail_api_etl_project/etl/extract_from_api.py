import requests
import pandas as pd

# --- Step 1: Get product data ---
products_url = "https://fakestoreapi.com/products"
products_data = requests.get(products_url).json()
df_products = pd.DataFrame(products_data)

# --- Step 2: Get order (cart) data ---
orders_url = "https://fakestoreapi.com/carts"
orders_data = requests.get(orders_url).json()

# Normalize orders
df_orders = pd.json_normalize(orders_data)[["id", "userId", "date"]]
df_orders.columns = ["order_id", "user_id", "order_date"]
df_orders["order_date"] = pd.to_datetime(df_orders["order_date"]).dt.date

# Flatten order items
df_order_items = pd.DataFrame([
    {
        "order_id": cart["id"],
        "product_id": item["productId"],
        "quantity": item["quantity"]
    }
    for cart in orders_data
    for item in cart["products"]
])

# --- Step 3: Save locally (optional backup) ---
df_products.to_csv("data/products.csv", index=False)
df_orders.to_csv("data/orders.csv", index=False)
df_order_items.to_csv("data/order_items.csv", index=False)

print("✅ Data extracted and saved.")
