import pandas as pd
import pyodbc
import ast

# Load CSV files
df_products = pd.read_csv("data/products.csv")
df_orders = pd.read_csv("data/orders.csv")
df_order_items = pd.read_csv("data/order_items.csv")

# SQL Server connection
conn = pyodbc.connect(
    "Driver={ODBC Driver 17 for SQL Server};"
    "Server=localhost;"
    "Database=RetailAPI;"
    "Trusted_Connection=yes;"
)
cursor = conn.cursor()

# Load products table
for _, row in df_products.iterrows():
    try:
        rating_dict = ast.literal_eval(row['rating'])
        rating_value = float(rating_dict['rate'])

        cursor.execute("""
            INSERT INTO products (id, title, price, description, category, image, rating)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        int(row['id']),
        str(row['title']),
        float(row['price']),
        str(row['description']),
        str(row['category']),
        str(row['image']),
        rating_value)
    except Exception as e:
        print(f"⚠️ Skipping product ID {row['id']}: {e}")

print("✅ Products table loaded.")

# Load orders table
for _, row in df_orders.iterrows():
    try:
        cursor.execute("""
            INSERT INTO orders (order_id, user_id, order_date)
            VALUES (?, ?, ?)
        """,
        int(row['order_id']),
        int(row['user_id']),
        str(row['order_date']))
    except Exception as e:
        print(f"⚠️ Skipping order ID {row['order_id']}: {e}")

print("✅ Orders table loaded.")

# Load order_items table
for _, row in df_order_items.iterrows():
    try:
        cursor.execute("""
            INSERT INTO order_items (order_id, product_id, quantity)
            VALUES (?, ?, ?)
        """,
        int(row['order_id']),
        int(row['product_id']),
        int(row['quantity']))
    except Exception as e:
        print(f"⚠️ Skipping order_item: {e}")

print("✅ Order_Items table loaded.")

# Commit and close connection
conn.commit()
cursor.close()
conn.close()
